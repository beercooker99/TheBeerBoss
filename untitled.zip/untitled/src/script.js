// Falling Beer Mug Animation
function createBeerMug() {
    const mug = document.createElement('div');
    mug.innerText = '🍺';
    mug.style.position = 'fixed';
    mug.style.left = Math.random() * window.innerWidth + 'px';
    mug.style.top = '-50px';
    mug.style.fontSize = '30px';
    mug.style.animation = 'fall 5s linear infinite';
    document.body.appendChild(mug);

    // Remove the beer mug after it falls out of view
    setTimeout(() => mug.remove(), 5000);
}

setInterval(createBeerMug, 1000); // Create a beer mug every second

// Add CSS for the falling animation
const style = document.createElement('style');
style.innerHTML = `
    @keyframes fall {
        0% { top: -50px; }
        100% { top: 100vh; }
    }
`;
document.head.appendChild(style);

// Back-to-Top Button
const topButton = document.createElement('button');
topButton.innerText = 'Back to Top';
topButton.style.position = 'fixed';
topButton.style.bottom = '20px';
topButton.style.right = '20px';
topButton.style.padding = '10px';
topButton.style.backgroundColor = '#28a745';
topButton.style.color = '#fff';
topButton.style.border = 'none';
topButton.style.borderRadius = '5px';
topButton.style.cursor = 'pointer';
topButton.style.display = 'none'; // Hide by default
document.body.appendChild(topButton);

// Show the button when scrolling down
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        topButton.style.display = 'block';
    } else {
        topButton.style.display = 'none';
    }
});

// Scroll smoothly to the top when clicked
topButton.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Light/Dark Mode Toggle Button
const toggleButton = document.createElement('button');
toggleButton.innerText = 'Toggle Theme';
toggleButton.style.position = 'fixed';
toggleButton.style.bottom = '60px';
toggleButton.style.right = '20px';
toggleButton.style.padding = '10px';
toggleButton.style.backgroundColor = '#007bff';
toggleButton.style.color = '#fff';
toggleButton.style.border = 'none';
toggleButton.style.borderRadius = '5px';
toggleButton.style.cursor = 'pointer';
document.body.appendChild(toggleButton);

// Toggle light/dark mode
let isDarkMode = false;
toggleButton.addEventListener('click', () => {
    document.body.style.backgroundColor = isDarkMode ? '#fafafa' : '#333';
    document.body.style.color = isDarkMode ? '#000' : '#fff';
    isDarkMode = !isDarkMode;
});

// Bubbly Button Animation
document.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', function (e) {
        const circle = document.createElement('span');
        const diameter = Math.max(button.clientWidth, button.clientHeight);
        const radius = diameter / 2;

        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = `${e.clientX - button.offsetLeft - radius}px`;
        circle.style.top = `${e.clientY - button.offsetTop - radius}px`;
        circle.classList.add('ripple');

        button.appendChild(circle);

        setTimeout(() => circle.remove(), 600);
    });
});

// Add CSS for bubbly button effect
const rippleStyle = document.createElement('style');
rippleStyle.innerHTML = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.7);
        transform: scale(0);
        animation: ripple 0.6s linear;
    }

    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);
